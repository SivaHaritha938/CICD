import React from 'react';
import { 
  GitBranch, 
  Server, 
  Cloud, 
  Container, 
  Database, 
  Shield, 
  BarChart, 
  Settings 
} from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: 'CI/CD & Version Control',
      icon: GitBranch,
      color: 'text-blue-400',
      skills: ['GitHub Actions', 'Jenkins', 'GitLab CI', 'Azure DevOps', 'Git', 'Bitbucket Pipelines']
    },
    {
      title: 'Cloud Platforms',
      icon: Cloud,
      color: 'text-green-400',
      skills: ['AWS', 'Azure', 'Google Cloud', 'DigitalOcean', 'Heroku', 'Vercel']
    },
    {
      title: 'Containerization',
      icon: Container,
      color: 'text-purple-400',
      skills: ['Docker', 'Kubernetes', 'OpenShift', 'Docker Compose', 'Podman', 'Helm']
    },
    {
      title: 'Infrastructure as Code',
      icon: Server,
      color: 'text-orange-400',
      skills: ['Terraform', 'Ansible', 'CloudFormation', 'Pulumi', 'Vagrant', 'Chef']
    },
    {
      title: 'Monitoring & Logging',
      icon: BarChart,
      color: 'text-yellow-400',
      skills: ['Prometheus', 'Grafana', 'ELK Stack', 'Datadog', 'New Relic', 'Splunk']
    },
    {
      title: 'Security & Compliance',
      icon: Shield,
      color: 'text-red-400',
      skills: ['OWASP', 'Vault', 'SonarQube', 'Snyk', 'Twistlock', 'Aqua Security']
    },
    {
      title: 'Databases',
      icon: Database,
      color: 'text-cyan-400',
      skills: ['PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'ElasticSearch', 'InfluxDB']
    },
    {
      title: 'Configuration Management',
      icon: Settings,
      color: 'text-pink-400',
      skills: ['Ansible', 'Puppet', 'Chef', 'SaltStack', 'Consul', 'Nomad']
    }
  ];

  return (
    <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Technical Expertise</h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Comprehensive DevOps toolkit spanning cloud platforms, automation, and infrastructure management
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg p-6 hover:scale-105 transition-all duration-300 hover:bg-slate-800/70"
            >
              <div className="flex items-center mb-4">
                <category.icon className={`h-8 w-8 ${category.color} mr-3`} />
                <h3 className="text-lg font-semibold text-white">{category.title}</h3>
              </div>
              <div className="space-y-2">
                {category.skills.map((skill, skillIndex) => (
                  <div
                    key={skillIndex}
                    className="bg-slate-700/50 text-slate-300 px-3 py-1 rounded-md text-sm font-medium"
                  >
                    {skill}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;