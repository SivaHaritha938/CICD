import React from 'react';
import { GitBranch, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-900 border-t border-slate-700 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <GitBranch className="h-6 w-6 text-blue-400" />
            <span className="text-lg font-semibold text-white">DevOps Pro</span>
          </div>
          
          <div className="flex items-center space-x-1 text-slate-300">
            <span>Built with</span>
            <Heart className="h-4 w-4 text-red-400 fill-current" />
            <span>and modern DevOps practices</span>
          </div>
          
          <div className="text-slate-400 text-sm mt-4 md:mt-0">
            © 2025 DevOps Portfolio. Auto-deployed with GitHub Actions.
          </div>
        </div>
        
        <div className="mt-8 pt-4 border-t border-slate-700 text-center">
          <p className="text-slate-400 text-sm">
            This site demonstrates automated CI/CD pipeline deployment. 
            Every commit triggers automated testing and deployment.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;