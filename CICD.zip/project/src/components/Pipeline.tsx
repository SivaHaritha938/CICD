import React, { useState } from 'react';
import { 
  Play, 
  GitBranch, 
  Wrench, 
  CheckCircle, 
  Upload, 
  Globe, 
  AlertCircle,
  Clock
} from 'lucide-react';

const Pipeline = () => {
  const [activeStep, setActiveStep] = useState(0);
  
  const pipelineSteps = [
    {
      id: 'source',
      icon: GitBranch,
      title: 'Source',
      description: 'Code pushed to repository',
      status: 'completed',
      color: 'bg-green-500',
      details: 'Triggered by push to main branch'
    },
    {
      id: 'build',
      icon: Wrench,
      title: 'Build',
      description: 'Dependencies installed and code compiled',
      status: 'completed',
      color: 'bg-blue-500',
      details: 'npm install && npm run build'
    },
    {
      id: 'test',
      icon: CheckCircle,
      title: 'Test',
      description: 'Unit and integration tests executed',
      status: 'running',
      color: 'bg-yellow-500',
      details: 'Jest tests, ESLint, and security scans'
    },
    {
      id: 'deploy',
      icon: Upload,
      title: 'Deploy',
      description: 'Application deployed to staging',
      status: 'waiting',
      color: 'bg-gray-500',
      details: 'Automated deployment to Vercel/Netlify'
    },
    {
      id: 'release',
      icon: Globe,
      title: 'Release',
      description: 'Live production deployment',
      status: 'waiting',
      color: 'bg-gray-500',
      details: 'Blue-green deployment strategy'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-400" />;
      case 'running':
        return <Clock className="h-5 w-5 text-yellow-400 animate-spin" />;
      case 'failed':
        return <AlertCircle className="h-5 w-5 text-red-400" />;
      default:
        return <div className="h-5 w-5 rounded-full bg-gray-500"></div>;
    }
  };

  return (
    <section id="pipeline" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">CI/CD Pipeline</h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Automated deployment pipeline with GitHub Actions demonstrating modern DevOps practices
          </p>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Play className="h-8 w-8 text-green-400" />
              <div>
                <h3 className="text-xl font-semibold text-white">Pipeline Status</h3>
                <p className="text-slate-400">Build #42 - Running</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-400">Duration: 2m 34s</p>
              <p className="text-sm text-slate-400">Commit: a7b3c2d</p>
            </div>
          </div>

          <div className="relative">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              {pipelineSteps.map((step, index) => (
                <div
                  key={step.id}
                  className={`flex-1 cursor-pointer transition-all duration-300 ${
                    activeStep === index ? 'scale-105' : ''
                  }`}
                  onClick={() => setActiveStep(index)}
                >
                  <div className="flex flex-col items-center space-y-2">
                    <div className={`w-16 h-16 rounded-full ${step.color} flex items-center justify-center relative`}>
                      <step.icon className="h-8 w-8 text-white" />
                      <div className="absolute -top-2 -right-2">
                        {getStatusIcon(step.status)}
                      </div>
                    </div>
                    <div className="text-center">
                      <h4 className="font-semibold text-white">{step.title}</h4>
                      <p className="text-sm text-slate-400">{step.description}</p>
                    </div>
                  </div>
                  {index < pipelineSteps.length - 1 && (
                    <div className="hidden md:block absolute top-8 left-1/2 transform -translate-y-1/2 w-full h-0.5 bg-slate-600 -z-10"></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 bg-slate-900/50 border border-slate-600 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-semibold text-white">
                {pipelineSteps[activeStep].title} Details
              </h4>
              <div className="flex items-center space-x-2">
                {getStatusIcon(pipelineSteps[activeStep].status)}
                <span className="text-sm text-slate-400 capitalize">
                  {pipelineSteps[activeStep].status}
                </span>
              </div>
            </div>
            <p className="text-slate-300 mb-4">{pipelineSteps[activeStep].details}</p>
            
            <div className="bg-slate-800 rounded-lg p-4 font-mono text-sm">
              <div className="text-green-400">$ github-actions-runner</div>
              <div className="text-slate-300 mt-2">
                {activeStep === 0 && "✓ Repository cloned successfully"}
                {activeStep === 1 && "✓ Dependencies installed (234 packages)"}
                {activeStep === 2 && "⏳ Running test suite..."}
                {activeStep === 3 && "⏳ Waiting for tests to complete"}
                {activeStep === 4 && "⏳ Awaiting deployment approval"}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pipeline;