import React from 'react';
import { ExternalLink, Github, Zap, Server, Cloud } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'Auto-Deploy Portfolio',
      description: 'This very portfolio with GitHub Actions CI/CD pipeline for automatic deployment to multiple platforms.',
      tech: ['React', 'TypeScript', 'GitHub Actions', 'Vercel', 'Tailwind CSS'],
      icon: Zap,
      color: 'text-blue-400',
      github: 'https://github.com/username/portfolio',
      live: 'https://portfolio.vercel.app',
      highlights: ['Automated testing', 'Multi-environment deployment', 'Zero-downtime updates']
    },
    {
      title: 'Microservices Infrastructure',
      description: 'Kubernetes-based microservices platform with automated scaling and monitoring.',
      tech: ['Docker', 'Kubernetes', 'Helm', 'Prometheus', 'Grafana'],
      icon: Server,
      color: 'text-green-400',
      github: 'https://github.com/username/k8s-microservices',
      live: 'https://api.example.com',
      highlights: ['Auto-scaling', 'Service mesh', 'Centralized logging']
    },
    {
      title: 'Cloud Cost Optimizer',
      description: 'Automated cloud resource optimization tool with cost tracking and recommendations.',
      tech: ['Python', 'AWS SDK', 'Terraform', 'Lambda', 'CloudWatch'],
      icon: Cloud,
      color: 'text-purple-400',
      github: 'https://github.com/username/cloud-optimizer',
      live: 'https://optimizer.example.com',
      highlights: ['40% cost reduction', 'Real-time monitoring', 'Automated recommendations']
    }
  ];

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Featured Projects</h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Real-world DevOps implementations showcasing automation, scalability, and best practices
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg p-6 hover:scale-105 transition-all duration-300 hover:bg-slate-800/70"
            >
              <div className="flex items-center mb-4">
                <project.icon className={`h-8 w-8 ${project.color} mr-3`} />
                <h3 className="text-xl font-semibold text-white">{project.title}</h3>
              </div>
              
              <p className="text-slate-300 mb-4">{project.description}</p>
              
              <div className="mb-4">
                <h4 className="text-sm font-semibold text-slate-400 mb-2">Key Highlights:</h4>
                <ul className="space-y-1">
                  {project.highlights.map((highlight, i) => (
                    <li key={i} className="text-sm text-slate-300 flex items-center">
                      <div className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-2"></div>
                      {highlight}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {project.tech.map((tech, i) => (
                  <span
                    key={i}
                    className="bg-slate-700/50 text-slate-300 px-2 py-1 rounded-md text-xs font-medium"
                  >
                    {tech}
                  </span>
                ))}
              </div>
              
              <div className="flex space-x-4">
                <a
                  href={project.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-slate-400 hover:text-blue-400 transition-colors"
                >
                  <Github className="h-4 w-4 mr-1" />
                  Code
                </a>
                <a
                  href={project.live}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-slate-400 hover:text-green-400 transition-colors"
                >
                  <ExternalLink className="h-4 w-4 mr-1" />
                  Live
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;