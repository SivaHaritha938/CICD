# DevOps Portfolio - CI/CD Showcase

A modern DevOps portfolio website built with React and TypeScript, featuring automated CI/CD pipeline deployment using GitHub Actions.

## 🚀 Features

- **Responsive Design**: Mobile-first design with Tailwind CSS
- **Interactive Pipeline**: Live CI/CD pipeline visualization
- **Auto-Deployment**: GitHub Actions workflow for automated deployment
- **Modern Stack**: React 18, TypeScript, Vite
- **Performance Optimized**: Code splitting and optimized builds
- **SEO Ready**: Proper meta tags and semantic HTML

## 🛠️ Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Build Tool**: Vite
- **Icons**: Lucide React
- **Deployment**: GitHub Pages, Vercel
- **CI/CD**: GitHub Actions

## 📦 Getting Started

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/devops-portfolio.git
   cd devops-portfolio
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Build for production**
   ```bash
   npm run build
   ```

## 🔄 CI/CD Pipeline

The project includes a comprehensive GitHub Actions workflow that:

1. **Source Control**: Triggers on push to main branch
2. **Build**: Installs dependencies and builds the project
3. **Test**: Runs linting and code quality checks
4. **Deploy**: Automatically deploys to GitHub Pages and Vercel

### Setting up Auto-Deployment

1. **GitHub Pages**: 
   - Enable GitHub Pages in repository settings
   - The workflow will automatically deploy to `gh-pages` branch

2. **Vercel**: 
   - Connect your repository to Vercel
   - Add the following secrets to your repository:
     - `VERCEL_TOKEN`: Your Vercel token
     - `ORG_ID`: Your Vercel organization ID
     - `PROJECT_ID`: Your Vercel project ID

## 🎯 Pipeline Visualization

The site features an interactive CI/CD pipeline visualization showing:
- Real-time pipeline status
- Step-by-step progression
- Detailed logs and information
- Modern DevOps workflow demonstration

## 🌟 Key Highlights

- **Zero-downtime deployments**: Blue-green deployment strategy
- **Automated testing**: Comprehensive test suite integration
- **Multi-environment support**: Staging and production environments
- **Performance monitoring**: Built-in analytics and monitoring
- **Security best practices**: Automated security scanning

## 📱 Responsive Design

The portfolio is fully responsive and optimized for:
- Mobile devices (< 768px)
- Tablets (768px - 1024px)
- Desktop screens (> 1024px)

## 🔧 Customization

1. **Update personal information** in the components
2. **Modify the pipeline steps** in `src/components/Pipeline.tsx`
3. **Add your projects** in `src/components/Projects.tsx`
4. **Customize the color scheme** in `tailwind.config.js`

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

Built with ❤️ and modern DevOps practices. Auto-deployed with GitHub Actions.